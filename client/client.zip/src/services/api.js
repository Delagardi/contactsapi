export default class ServiceAPI {
  
}