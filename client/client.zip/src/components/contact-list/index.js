import ContactList from './contact-list';

export default ContactList;