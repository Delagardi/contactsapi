import ContactItem from './contact-item';

export default ContactItem;