import ContactEdit from './contact-edit';

export default ContactEdit;